-- 1. VERSENYEK TABLA

-- uj verseny bezsurasa
INSERT IGNORE INTO versenyek (verseny_neve, lokalis, regionalis, orszagos, nemzetkozi) 
VALUES ('Kenguru Matematikaverseny', 0, 0, 1, 0);

-- kategoriak tomeges frissitese nev alapjan
UPDATE versenyek 
SET nemzetkozi = 1, orszagos = 0, regionalis = 0, lokalis = 0
WHERE verseny_neve LIKE '%Világbajnokság%';

-- eredmeny nelkuli versenyek torlese
DELETE FROM versenyek 
WHERE verseny_id NOT IN (SELECT DISTINCT verseny_id FROM eredmenyek);

-- nev formazas
UPDATE versenyek 
SET verseny_neve = TRIM(verseny_neve);

-- beszuras, vagy frissites ha letezik
INSERT INTO versenyek (verseny_neve, lokalis, regionalis, orszagos, nemzetkozi) 
VALUES ('OKTV', 0, 0, 1, 0)
ON DUPLICATE KEY UPDATE orszagos = 1, nemzetkozi = 0;

-- 2. TANEV TABLA

-- kovetkezo tanev automatikus hozzaadas
INSERT INTO tanev (megnevezes)
SELECT MAX(megnevezes) + 1 FROM tanev;

-- esetleges elgepelt tanev atnevezese
UPDATE tanev 
SET megnevezes = 2024 
WHERE megnevezes = 20224;

-- regi, nem hasznalt tanevek torlese
DELETE FROM tanev 
WHERE megnevezes < 2015 AND tanev_id NOT IN (SELECT tanev_id FROM eredmenyek);

-- tobb tanev hozzaadasa egyszerre
INSERT IGNORE INTO tanev (megnevezes) VALUES (2025), (2026), (2027);

-- minden tanev eltolasa 1-gyel
UPDATE tanev SET megnevezes = megnevezes + 1;

-- 3. DIAKOK TABLA

-- hianyzo profilkepek potlasa
UPDATE diakok 
SET foto_url = '/img/default_avatar.png' 
WHERE foto_url IS NULL OR foto_url = '';

-- vezeteknevek egyesitese nagybeture
UPDATE diakok 
SET diak_vezeteknev = UPPER(diak_vezeteknev);

-- adott diak torlese
DELETE FROM diakok WHERE diak_id = 3;

-- hibas karakterek csereje
UPDATE diakok 
SET diak_keresztnev = REPLACE(diak_keresztnev, 'ö', 'ő')
WHERE diak_keresztnev LIKE '%õ%';

-- diak profiljanak klonozasa
INSERT INTO diakok (diak_vezeteknev, diak_keresztnev, foto_url)
SELECT diak_vezeteknev, CONCAT(diak_keresztnev, ' Junior'), foto_url 
FROM diakok WHERE diak_id = 1;

-- 4. BEALLITASOK TABLA

-- fejlec szovegenek frissitese legutolso tanevre
UPDATE beallitasok 
SET fejlec_szoveg = CONCAT('Dicsőségfal ', (SELECT MAX(megnevezes) FROM tanev));

-- kepek eleresenek tomeges mappavaltas eseten
UPDATE beallitasok 
SET logo_url = REPLACE(logo_url, '/img/', '/assets/images/');

-- teljes beallitasok torlese
DELETE FROM beallitasok;

-- varosnev egyesitese
UPDATE beallitasok 
SET helyszin = 'Fehérgyarmat' 
WHERE helyszin LIKE '%fehergyarmat%' OR helyszin LIKE '%Fehér gyarmat%';

-- egyetlen aktiv sor beallitasa
REPLACE INTO beallitasok (id, fejlec_szoveg, logo_url, iskola_neve, helyszin)
VALUES (1, 'Hivatalos Dicsőségfal', '/logo.png', 'Gimnázium', 'Budapest');

-- 5. TANAROK TABLA

-- keresztnev vagy vezeteknev felcserelese
UPDATE tanarok 
SET 
    tanar_vezeteknev = (@temp := tanar_vezeteknev), 
    tanar_vezeteknev = tanar_keresztnev, 
    tanar_keresztnev = @temp 
WHERE tanar_id = 5;

-- minden profilkep torlese
UPDATE tanarok SET profilkep = NULL;

-- konkret tanar torlese nev alapjan
DELETE FROM tanarok 
WHERE tanar_vezeteknev = 'Kiss' AND tanar_keresztnev = 'Zoltán';

-- titulus hozzaadasa
UPDATE tanarok 
SET tanar_vezeteknev = CONCAT('Dr. ', tanar_vezeteknev) 
WHERE tanar_id = 4 AND tanar_vezeteknev NOT LIKE 'Dr.%';

-- inaktiv tanarok eltavolitasa
DELETE FROM tanarok 
WHERE tanar_id NOT IN (SELECT tanar_id FROM tanar_felkeszit_eredmeny);

-- 6. USER TABLA

-- jelszocsere hash
UPDATE `user` 
SET jelszo = SHA2('UjBiztosJelszo2024!', 256) 
WHERE felhasznalonev = 'admin_teszt';

-- gyanus nevu felhasznalok torlese
DELETE FROM `user` 
WHERE felhasznalonev LIKE '%test%' OR felhasznalonev LIKE '%hack%';

-- felhasznalonevek kisbetu, es szokozmentesites
UPDATE `user` 
SET felhasznalonev = LOWER(TRIM(felhasznalonev));

-- jogusultsagok megvonasa teljes torlessel
DELETE FROM `user` WHERE user_id = 3;

-- uj admin beszurasa ha nem letezik
INSERT INTO `user` (felhasznalonev, jelszo)
SELECT 'uj_admin', 'ErosJelszo123!' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `user` WHERE felhasznalonev = 'uj_admin');

-- 7. CIKK TABLA

-- nem kivant tartalmak cenzurasa
UPDATE cikk 
SET cikk_tartalom = REPLACE(cikk_tartalom, 'rossz_szo', '***') 
WHERE cikk_tartalom LIKE '%rossz_szo%';

-- cikk szerzosegenek atruhazasa
UPDATE cikk 
SET user_id = 1 
WHERE user_id = 2;

-- regi cikkek torlese
DELETE FROM cikk 
WHERE HOUR(letrehozas_ideje) < 10;

-- ido modositasa a mostani pontos idore
UPDATE cikk 
SET letrehozas_ideje = CURRENT_TIME();

-- foto linkek kiegeszitese CDN utvonallal
UPDATE cikk 
SET versenyfotok = CONCAT('https://cdn.iskolam.hu', versenyfotok) 
WHERE versenyfotok IS NOT NULL AND versenyfotok NOT LIKE 'http%';

-- 8. EREDMENYEK TABLA

-- helyezesek egysegesitese
UPDATE eredmenyek 
SET konkret_eredmeny = '1. helyezés' 
WHERE konkret_eredmeny IN ('1. hely', 'Első hely', 'I. helyezés');

-- eredmeny athelyezese egy masik cikkhez
UPDATE eredmenyek 
SET cikk_id = 5 
WHERE eredmeny_id = 10;

-- hibas evfolyamhoz tartozo eredmenyek torlese
DELETE FROM eredmenyek 
WHERE tanev_id = 1;

-- eredmeny lemasolasa masik diakhoz (pl csapatverseny)
INSERT INTO eredmenyek (diak_id, verseny_id, tanev_id, cikk_id, konkret_eredmeny)
SELECT 2, verseny_id, tanev_id, cikk_id, konkret_eredmeny 
FROM eredmenyek WHERE eredmeny_id = 3;

-- verseny nevenek hozzafuzese a konkret eredmeny szovegehez
UPDATE eredmenyek e
JOIN versenyek v ON e.verseny_id = v.verseny_id
SET e.konkret_eredmeny = CONCAT(e.konkret_eredmeny, ' (', v.verseny_neve, ')');

-- 9. TANAR_FELKESZIT_EREDMENY TABLA

-- felkeszito tanar csereje
UPDATE tanar_felkeszit_eredmeny 
SET tanar_id = 4 
WHERE tanar_id = 2 AND eredmeny_id = 15;

-- teves osszerendeles torlese
DELETE FROM tanar_felkeszit_eredmeny 
WHERE tanar_id = 5 AND eredmeny_id = 22;

-- egy tanar hozzaadasa az adott verseny osszes eredmenyehez
INSERT IGNORE INTO tanar_felkeszit_eredmeny (tanar_id, eredmeny_id)
SELECT 1, eredmeny_id FROM eredmenyek WHERE verseny_id = 1;

-- egy tanar felkeszitesenek torlese
DELETE FROM tanar_felkeszit_eredmeny WHERE tanar_id = 3;

-- ket tanar adatainak osszevonasa
UPDATE IGNORE tanar_felkeszit_eredmeny 
SET tanar_id = 2 
WHERE tanar_id = 7;

-- 10. USER_KEZELI_EREDMENY TABLA

-- hozzaferes atadasa masik adminnak
UPDATE IGNORE user_kezeli_eredmeny 
SET user_id = 6 
WHERE user_id = 4;

-- szuperadmin jog atadasa minden eredmenyhez
INSERT IGNORE INTO user_kezeli_eredmeny (user_id, eredmeny_id)
SELECT 1, eredmeny_id FROM eredmenyek;

-- egy cikkhez valo jogosultsag elvetele egy admintol
DELETE uke FROM user_kezeli_eredmeny uke
JOIN eredmenyek e ON uke.eredmeny_id = e.eredmeny_id
WHERE uke.user_id = 3 AND e.cikk_id = 10;

-- duplikalt kezeloi jog megszuntetese
DELETE u1 FROM user_kezeli_eredmeny u1
JOIN user_kezeli_eredmeny u2 ON u1.eredmeny_id = u2.eredmeny_id
WHERE u1.user_id > u2.user_id;

-- egyedi hozzaferes rogzitese
INSERT IGNORE INTO user_kezeli_eredmeny (user_id, eredmeny_id) 
VALUES (2, 45);